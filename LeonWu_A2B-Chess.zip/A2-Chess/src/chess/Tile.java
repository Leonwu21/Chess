package chess;

import javafx.scene.Group;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;

/**
 * This class represents the square tiles on the chess board.
 * @author Leon Wu
 * @version 1.0
 */
public class Tile {
    /** Length of each tile. */
    static int length;
    /** Width of each tile. */
    static int width;
    /** True if tile is white. */
    private boolean white;
    /** Node used as tile representation. */
    public Rectangle rectangle;
    /** Groups the rectangles for the JavaFX scene. */
    public Group root;

    /** Initializes all aspects of the Tile class. */
    public Tile() {
        length = 50;
        width = 50;
        rectangle = new Rectangle(length, width);
        white = false;
        root = new Group();
        root.getChildren().add(rectangle);
    }
    
    /**
     * Returns the length of the tile.
     * @return length
     */
    public static int getLength() {
        return length;
    }
    
    /**
     * Returns the width of the tile
     * @return width
     */
    public static int getWidth() {
        return width;
    }
    
    /** Sets the boolean white to be true. */
    public void setWhite() {
        white = true;
    }
    
    /** Sets the colors of the tiles. */
    public void setColor() {
        if (white) {
            rectangle.setFill(Color.WHITE);
        } else {
            rectangle.setFill(Color.BLACK);
        }
    }
    
    /** Returns true if tile is white. */
    public boolean isWhite() {
        return white;
    }
    
}
