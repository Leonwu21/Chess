package chess;

import javafx.scene.image.Image;

/**
 * This class represents the chess piece images to be set on the board.
 * @author Leon Wu
 * @version 1.0
 */
public class ChessPiece {
    
    /** Stores an image representing the red pawn. */
    private Image pawnR;
    /** Stores an image representing the blue pawn. */
    private Image pawnB;
    /** Stores an image representing the red king. */
    private Image kingR;
    /** Stores an image representing the blue king. */
    private Image kingB;
    /** Stores an image representing the red queen. */
    private Image queenR;
    /** Stores an image representing the blue queen. */
    private Image queenB;
    /** Stores an image representing the red bishop. */
    private Image bishopR;
    /** Stores an image representing the blue bishop. */
    private Image bishopB;
    /** Stores an image representing the red rook. */
    private Image rookR;
    /** Stores an image representing the blue rook. */
    private Image rookB;
    /** Stores an image representing the red knight. */
    private Image knightR;
    /** Stores an image representing the blue knight. */
    private Image knightB;
    
    public final String PAWNR = "File:src\\chess\\images\\PawnR.png";
    public final String PAWNB = "File:src\\chess\\images\\PawnB.png";
    public final String KINGR = "File:src\\chess\\images\\KingR.png";
    public final String KINGB = "File:src\\chess\\images\\KingB.png";
    public final String QUEENR = "File:src\\chess\\images\\QueenR.png";
    public final String QUEENB = "File:src\\chess\\images\\QueenB.png";
    public final String BISHOPR = "File:src\\chess\\images\\BishopR.png";
    public final String BISHOPB = "File:src\\chess\\images\\BishopB.png";
    public final String ROOKR = "File:src\\chess\\images\\RookR.png";
    public final String ROOKB = "File:src\\chess\\images\\RookB.png";
    public final String KNIGHTR = "File:src\\chess\\images\\KnightR.png";
    public final String KNIGHTB = "File:src\\chess\\images\\KnightB.png";
    
    /** Instantiates all images. */
    public ChessPiece() {
        pawnR = new Image(PAWNR);
        pawnB = new Image(PAWNB);
        kingR = new Image(KINGR);
        kingB = new Image(KINGB);
        queenR = new Image(QUEENR);
        queenB = new Image(QUEENB);
        bishopR = new Image(BISHOPR);
        bishopB = new Image(BISHOPB);
        rookR = new Image(ROOKR);
        rookB = new Image(ROOKB);
        knightR = new Image(KNIGHTR);
        knightB = new Image(KNIGHTB);
    }
    
    /**
     * Returns the Image of the red pawn.
     * @return pawnR Image
     */
    public Image getPawnR() {
        return pawnR;
    }
    
    /**
     * Returns the Image of the blue pawn.
     * @return pawnB Image
     */
    public Image getPawnB() {
        return pawnB;
    }
    
    /**
     * Returns the Image of the red queen.
     * @return queenR Image
     */
    public Image getQueenR() {
        return queenR;
    }
    
    /**
     * Returns the Image of the blue queen.
     * @return queenB Image
     */
    public Image getQueenB() {
        return queenB;
    }
    
    /**
     * Returns the Image of the red king.
     * @return kingR Image
     */
    public Image getKingR() {
        return kingR;
    }
    
    /**
     * Returns the Image of the blue king.
     * @return kingB Image
     */
    public Image getKingB() {
        return kingB;
    }
    
    /**
     * Returns the Image of the red bishop.
     * @return bishopR Image
     */
    public Image getBishopR() {
        return bishopR;
    }
    
    /**
     * Returns the Image of the blue bishop.
     * @return bishopB Image
     */
    public Image getBishopB() {
        return bishopB;
    }
    
    /**
     * Returns the Image of the red rook.
     * @return rookR Image
     */
    public Image getRookR() {
        return rookR;
    }
    
    /**
     * Returns the Image of the blue rook.
     * @return rookB Image
     */
    public Image getRookB() {
        return rookB;
    }
    
    /**
     * Returns the Image of the red knight.
     * @return knightR Image
     */
    public Image getKnightR() {
        return knightR;
    }
    
    /**
     * Returns the Image of the blue knight.
     * @return knightB Image
     */
    public Image getKnightB() {
        return knightB;
    }
    
}
