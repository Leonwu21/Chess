package chess;

import javafx.application.Application;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

/**
 * This is the main board program that drives the chess game.
 * @author Leon Wu
 * @version 1.0
 */
public class Boardv2 extends Application{
    /** Tiles to be laid onto the board. */
    private Tile[][] tiles;
    /** GridPane to be used. */
    private GridPane grid;
    /** ChessPiece images to be laid onto the tiles. */
    private ChessPiece piece;
    /** Scene to be set. */
    private Scene scene;
    /** ImageView set for ChessPiece images. */
    private ImageView set;
    /** EventHandler for mouse click events. */
    EventHandler boardHandler;
    /** ImageView to be stored on mouse clicks. */
    ImageView stored;
    
    /** Initializes all aspects of the board. */
    public Boardv2() {
        tiles = new Tile[8][8];
        grid = new GridPane();
        boardHandler = new EventHandler();
        createTiles();
        setTiles(Tile.getLength(), Tile.getWidth());
        piece = new ChessPiece();
        setPawns();
        setRooks();
        setKnights();
        setBishops();
        setQueens();
        setKings();
    }
    
    /**
     * Sets the tiles array onto the GridPane.
     * @param length of tiles
     * @param width of tiles
     */
    public void setTiles(int length, int width) {
        for (int i = 0; i < 8; i ++) {
            for (int j = 0; j < 8; j++) {
                grid.setOnMouseClicked(this.boardHandler::clickGrid);
                grid.add(tiles[i][j].root, i, j);
                if (i % 2 == 0) {
                    if (j % 2 == 1) {
                        tiles[i][j].setWhite();
                        tiles[i][j].setColor();
                    }
                } else {
                    if (j % 2 == 0) {
                        tiles[i][j].setWhite();
                        tiles[i][j].setColor();
                    }
                }
            }
        }
    }
    /**
     * Inner class that handles mouse click events.
     * @author Leon Wu
     * @version 1.0
     */
    public class EventHandler {
        /**
         * Handles a mouse click event by storing and "moving" pieces.
         * @param event mouse click
         */
        public void clickGrid(MouseEvent event) {
            
            Node clickedNode = event.getPickResult().getIntersectedNode();
            Node parent = clickedNode;
            if (clickedNode != grid) {
                parent = clickedNode.getParent();
                while (parent != grid) {
                    clickedNode = parent;
                    parent = clickedNode.getParent(); 
                    
                }
            }
        Integer colIndex = GridPane.getColumnIndex(clickedNode);
        Integer rowIndex = GridPane.getRowIndex(clickedNode);
        grid.add(stored, colIndex, rowIndex);
        setClick(stored, stored.getImage());
        System.out.println(stored.getImage());
        }
    }
    
    /**
     * Sets ChessPieces onto grid and sets mouse click listener.
     * @param view as ImageView
     * @param img as Image
     * @param col as grid column
     * @param row as grid row
     */
    public void setPiece(ImageView view, Image img, int col, int row) {
        view = new ImageView(img);
        grid.add(view, col, row);
        setClick(view, view.getImage());
    }
    
    /** Sets all pawn ChessPieces. */
    public void setPawns() {
        for (int j = 0; j < 8; j++)
            setPiece(set, piece.getPawnR(), j, 1);
        for (int j = 0; j < 8; j++)
            setPiece(set, piece.getPawnB(), j, 6);
    }
    
    /** Sets all rook ChessPieces. */
    public void setRooks() {
        setPiece(set, piece.getRookR(), 0, 0);
        setPiece(set, piece.getRookR(), 7, 0);
        setPiece(set, piece.getRookB(), 0, 7);
        setPiece(set, piece.getRookB(), 7, 7);
    }

    /** Sets all knight ChessPieces. */
    public void setKnights() {
        setPiece(set, piece.getKnightR(), 1, 0);
        setPiece(set, piece.getKnightR(), 6, 0);
        setPiece(set, piece.getKnightB(), 1, 7);
        setPiece(set, piece.getKnightB(), 6, 7);
    }
    
    /** Sets all bishop ChessPieces. */
    public void setBishops() {
        setPiece(set, piece.getBishopR(), 2, 0);
        setPiece(set, piece.getBishopR(), 5, 0);
        setPiece(set, piece.getBishopB(), 2, 7);
        setPiece(set, piece.getBishopB(), 5, 7);
    }
    
    /** Sets all queen ChessPieces. */
    public void setQueens() {
        setPiece(set, piece.getQueenR(), 3, 0);
        setPiece(set, piece.getQueenB(), 3, 7);
    }
    /** Sets all king ChessPieces. */
    public void setKings() {
        setPiece(set, piece.getKingR(), 4, 0);
        setPiece(set, piece.getKingB(), 4, 7);
    }
    
    /**
     * Sets the mouse click event handler.
     * @param view as ImageView
     * @param img as Image
     */
    public void setClick(ImageView view, Image img) {
        view.setOnMouseClicked(e -> {
            stored = new ImageView(img);
            view.setImage(null);
        });
    }
    
    /** Creates the tiles of the tiles array to be set onto the grid. */
    public void createTiles() {
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                tiles[i][j] = new Tile();
            }
        }
    }

    /** Sets the JavaFX scene and stage. 
     * @param stage sets the scene
     */
    @Override
    public void start(Stage stage) throws Exception {
        Boardv2 board = new Boardv2();
        scene = new Scene(board.grid, 400, 400);
        stage.setScene(scene);
        stage.setTitle("Tiles");
        stage.show();
    }
    
    /**
     * Launches the JavaFX application.
     * @param args unused
     */
    public static void main(String[] args) {
        Application.launch(args);
    }
}
